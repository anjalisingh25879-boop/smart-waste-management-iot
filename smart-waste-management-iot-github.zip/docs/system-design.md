# System Design Notes

## Purpose
The prototype illustrates how fill-level information from distributed waste bins could support monitoring and collection planning.

## Conceptual data flow
1. An ultrasonic sensor measures the distance from the sensor to the waste surface.
2. A microcontroller converts distance into an estimated fill percentage.
3. A communication module can send timestamped readings to a backend (not implemented in this starter).
4. A backend can validate and store readings.
5. A dashboard can display current status and historical trends.
6. Collection staff or managers can use the information alongside local operational constraints.

## Status rule in the demo
The browser demo labels a bin as “Collection needed” when the fill estimate is at least 80%. This is an illustrative threshold only. Determine a real threshold through field testing and operational requirements.

## Reliability and safety considerations
- Validate sensor readings and handle timeouts.
- Account for uneven waste surfaces, sensor placement, moisture, and obstruction.
- Protect device credentials and use authenticated, encrypted communication in a deployed system.
- Define data retention, user access, and device update procedures.
- Test alerts and failure behavior before operational use.

## AI extension (not implemented)
Forecasting or route optimization would require reliable historical readings, collection timestamps, bin locations, and operational constraints. Establish a baseline first, then evaluate models against held-out data and document error rates and limitations.
