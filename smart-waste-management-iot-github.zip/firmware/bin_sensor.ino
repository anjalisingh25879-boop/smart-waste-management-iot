/*
  Smart bin fill-level sensor example
  Example wiring: TRIG -> GPIO 5, ECHO -> GPIO 18 (ESP32 example).
  Use a voltage divider/level shifter on HC-SR04 ECHO for ESP32.
  Confirm pins and voltage requirements for your board.
*/
const int TRIG_PIN = 5;
const int ECHO_PIN = 18;
const float BIN_DEPTH_CM = 100.0; // Measure and set for your bin

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIG_PIN, LOW);
}

float readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);
  if (duration == 0) return -1.0; // timeout / no valid echo
  return duration * 0.0343 / 2.0;
}

void loop() {
  float distance = readDistanceCm();
  if (distance < 0) {
    Serial.println("ERROR,no_echo");
  } else {
    float fill = (1.0 - distance / BIN_DEPTH_CM) * 100.0;
    fill = constrain(fill, 0.0, 100.0);
    Serial.print("distance_cm,");
    Serial.print(distance, 1);
    Serial.print(",fill_percent,");
    Serial.println(fill, 1);
  }
  delay(5000);
}
