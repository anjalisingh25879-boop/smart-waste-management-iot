const locations = ["Main Gate", "Hostel Block A", "Cafeteria", "Library", "Workshop", "North Wing"];
let bins = [
  {id:"BIN-001",location:locations[0],fill:34},
  {id:"BIN-002",location:locations[1],fill:82},
  {id:"BIN-003",location:locations[2],fill:67},
  {id:"BIN-004",location:locations[3],fill:21},
  {id:"BIN-005",location:locations[4],fill:93},
  {id:"BIN-006",location:locations[5],fill:48}
];
const urgent = bin => bin.fill >= 80;
function render(){
  const filter=document.querySelector("#statusFilter").value;
  const shown=bins.filter(b=>filter==="all"||(filter==="urgent"?urgent(b):!urgent(b)));
  document.querySelector("#totalBins").textContent=bins.length;
  document.querySelector("#urgentBins").textContent=bins.filter(urgent).length;
  document.querySelector("#averageFill").textContent=Math.round(bins.reduce((s,b)=>s+b.fill,0)/bins.length)+"%";
  document.querySelector("#binRows").innerHTML=shown.map(b=>{
    const high=urgent(b);
    return `<tr><td><strong>${b.id}</strong></td><td>${b.location}</td><td><div class="level"><div class="track"><div class="bar ${high?"high":""}" style="width:${b.fill}%"></div></div><strong>${b.fill}%</strong></div></td><td><span class="status ${high?"urgent":"normal"}">${high?"Collection needed":"Normal"}</span></td><td>${new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</td></tr>`;
  }).join("");
}
document.querySelector("#refreshBtn").addEventListener("click",()=>{
  bins=bins.map(b=>({...b,fill:Math.max(0,Math.min(100,b.fill+Math.round(Math.random()*24-9)))}));
  render();
});
document.querySelector("#statusFilter").addEventListener("change",render);
render();
